from .PIDController import Variable, PIDController
from .example import test
__version__ = '0.0.6'

def sayit():
    print("Now you have me! ({})".format(__version__))